from flask import Flask, render_template, request, redirect, url_for, session
from flask_session import Session  # Import Session from flask_session
import csv

app = Flask(__name__)
app.secret_key = 'secret'
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)

'''
# Define MenuItem, FoodItem, DrinkItem, and Order classes
class MenuItem:
    def __init__(self, name, price):
        self.name = name
        self.price = price

    def get_name(self):
        return self.name

    def get_price(self):
        return self.price
'''

class MenuItem:
    def __init__(self, name, price):
        self.name = name
        self.price = price

    def get_name(self):
        return self.name
    
    def get_price(self):
        return self.price


class FoodItem(MenuItem):
    def __init__(self, name, price):
        self.name = name
        self.price = price

    def get_name(self):
        return self.name
    
    def get_price(self):
        return self.price
    
class DrinkItem(MenuItem):
    def __init__(self, name, price):
        self.name = name
        self.price = price

    def get_name(self):
        return self.name
    
    def get_price(self):
        return self.price

def load_menu_items(filename='Menu.csv'):
    items = []
    with open(filename, newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            if 'ItemType' in row:
                item_type = row['ItemType'].capitalize()
            else:
                # Handle the case when 'type' key is missing
                item_type = None  # or any default value you prefer
            item = None
            if item_type == 'Food':
                item = FoodItem(row['ItemName'], float(row['Price']))
            elif item_type == 'Drink':
                item = DrinkItem(row['ItemName'], float(row['Price']))
            if item:
                items.append(item)
    return items

menu_items = load_menu_items()  # Load menu items from CSV

'''
class FoodItem(MenuItem):
    def __init__(self, name, price, category):
        super().__init__(name, price)
        self.category = category

    def get_category(self):
        return self.category

class DrinkItem(MenuItem):
    def __init__(self, name, price, size, is_alcoholic):
        super().__init__(name, price)
        self.size = size
        self.is_alcoholic = is_alcoholic

    def get_size(self):
        return self.size

    def get_alcohol_content(self):
        return "Alcoholic" if self.is_alcoholic else "Non-alcoholic"
    '''

class Order:
    def __init__(self):
        self.items = []
        self.total_cost = 0

    def add_item(self, item):
        self.items.append(item)

    def get_total_cost(self):
        return sum(item.get_price() for item in self.items)

    def reset(self):
        self.items = []
        self.total_cost = 0

'''
# Example menu items...
menu_items = [
    FoodItem("Burger", 5.99, "Main"),
    FoodItem("Fries", 2.99, "Side"),
    DrinkItem("Cola", 1.99, "Medium", False),
    DrinkItem("Beer", 3.99, "Medium", True)
]
'''

def get_order():
    if 'order' not in session:
        session['order'] = Order()  # Instantiate a new Order object
    return session['order']

@app.route('/', methods=['GET', 'POST'])
def chat():
    if request.method == 'POST':
        user_input = request.form.get('user_input', '').strip()
        if user_input:
            order = get_order()
            response, reset = process_input(user_input, order)
            update_chat_history("You", user_input)
            update_chat_history("Bot", response)
            session.modified = True
            if reset:
                session['chat_history'] = []
                update_chat_history("Bot", "Hello! Please tell me what you would like to order.")
            return redirect(url_for('chat'))
    else:
        if 'chat_history' not in session:
            session['chat_history'] = []
            update_chat_history("Bot", "Hello! Please tell me what you would like to order.")
            session.modified = True
    return render_template('chat.html', chat_history=session.get('chat_history', []), menu_items=menu_items)




def update_chat_history(speaker, message):
    if 'chat_history' not in session:
        session['chat_history'] = []
    session['chat_history'].append({"user": speaker, "bot": message})
    print("Updated chat history:", session['chat_history'])  # Debugging output
    session.modified = True



def process_input(user_input, order):
    user_input = user_input.lower().strip()
    if user_input == "reset":
        order.reset()
        return "Your order has been reset. What would you like to order now?", True
    elif "done" in user_input:
        total_cost = order.get_total_cost()
        items_summary = ', '.join(f"{item.name} (${item.price})" for item in order.items)
        return f"Order Summary: {items_summary}. Total cost: ${total_cost:.2f}. Thank you! Your order has been processed.", False
    found_item = find_menu_item(user_input)
    if found_item:
        order.add_item(found_item)
        total_cost = order.get_total_cost()
        return f"Added {found_item.get_name()} to your order. Current total: ${total_cost:.2f}. Anything else?", False
    return "I'm not sure I understood that. Can you specify what you'd like to order?", False



def find_menu_item(user_input):
    for item in menu_items:
        if item.get_name().lower() in user_input:
            return item
    return None

@app.route('/summary')
def summary():
    order = get_order()  # Retrieve the order from the session
    total_cost = order.get_total_cost()
    order.reset()  # Reset the order after displaying the summary
    update_chat_history("Bot", f"Your total is ${total_cost}. Thank you for your order!")
    session.modified = True
    return redirect(url_for('chat'))

if __name__ == '__main__':
    app.run(debug=True)
